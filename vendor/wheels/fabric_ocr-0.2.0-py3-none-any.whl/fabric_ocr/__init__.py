"""Client of the AI Fabric OCR service: the SDK (`fabric_ocr.client`) and the command line (`fabric-ocr`).

Design: fabric/docs/navrh-ocr.md §10.3; distribution: fabric/docs/navrh-klienti-a-balicky.md.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("fabric-ocr")
except PackageNotFoundError:          # run from a source tree that was never installed
    __version__ = "0.0.0"
