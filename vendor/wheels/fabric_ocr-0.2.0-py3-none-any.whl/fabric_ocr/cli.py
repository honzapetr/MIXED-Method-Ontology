"""`fabric-ocr` - read a file or extract data from it with the AI Fabric OCR service.

    fabric-ocr read faktura.pdf                          # Markdown on stdout, route / quality / warnings on stderr
    fabric-ocr read foto.jpg --mode accurate --json > vysledek.json
    fabric-ocr read https://host/sken.pdf --pages 1-3    # a URL the service may download (its allowed hosts)
    fabric-ocr extract kalendar.jpg --schema akce.json --instruction "Vypiš akce s datem." --context "listopad 2026"
    fabric-ocr read velky.pdf --no-wait                  # prints the job id; later: fabric-ocr job <id>
    fabric-ocr status

Address and token: FABRIC_OCR_URL and FABRIC_OCR_TOKEN, or the same KEY=VALUE lines in ~/.config/fabric-ocr/env (the
environment wins). Exit code: 0 done, 2 done but only `basic` / `suspect` quality (the CPU fallback read it), 1 error.
"""

import argparse
import json
import os
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any, TextIO

from fabric_ocr import __version__
from fabric_ocr.client import DEFAULT_TIMEOUT_S, OcrApiError, OcrClient, Source, connect

URL_KEY = "FABRIC_OCR_URL"
TOKEN_KEY = "FABRIC_OCR_TOKEN"
CONFIG_FILE = Path.home() / ".config" / "fabric-ocr" / "env"
EXIT_OK, EXIT_ERROR, EXIT_LOW_QUALITY = 0, 1, 2
FULL_QUALITY = "full"


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="fabric-ocr", description="AI Fabric OCR service: read or extract.",
                                   epilog=f"Config: {URL_KEY}, {TOKEN_KEY} (environment or {CONFIG_FILE}).")
    root.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = root.add_subparsers(dest="command", required=True)

    def waiting(command: argparse.ArgumentParser) -> None:
        command.add_argument("--json", action="store_true", help="the whole answer as JSON on stdout")
        command.add_argument("--no-wait", action="store_true", help="do not wait for a running job, print its id")
        command.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT_S, help="how long to wait, seconds")

    read = commands.add_parser("read", help="a file or URL → text (Markdown)")
    read.add_argument("source", help="a local file or an http(s) URL")
    read.add_argument("--mode", choices=["auto", "accurate", "fast"], default="auto",
                      help="auto: text layer or the model; accurate: always the model; fast: CPU only")
    read.add_argument("--pages", default="", help="e.g. 1-3,7")
    waiting(read)

    extract = commands.add_parser("extract", help="a photo / scan / PDF → JSON valid against a schema")
    extract.add_argument("source", help="a local file or an http(s) URL")
    extract.add_argument("--schema", required=True, type=Path, help="JSON Schema file of the result")
    extract.add_argument("--instruction", required=True, help="what to extract (text, or @file to read it from a file)")
    extract.add_argument("--context", default="", help="what the model should know, e.g. the month or the school year")
    extract.add_argument("--pages", default="", help="e.g. 1-2")
    waiting(extract)

    job = commands.add_parser("job", help="a job started with --no-wait: its state or result")
    job.add_argument("job_id")
    waiting(job)

    commands.add_parser("status", help="where the OCR model runs now, limits, allowed source hosts")
    return root


def settings(env: Mapping[str, str], config_file: Path = CONFIG_FILE) -> tuple[str, str]:
    """(url, token) from the environment, else from the config file; a missing one is an error with the fix."""
    values = _env_file(config_file) | {k: v for k, v in env.items() if k in (URL_KEY, TOKEN_KEY) and v}
    missing = [key for key in (URL_KEY, TOKEN_KEY) if not values.get(key)]
    if missing:
        raise OcrApiError(0, f"set {' and '.join(missing)} (environment or {config_file}); the token is your app's "
                             "OCR_CLIENT_TOKEN_<NAME> from /etc/mcp-hub/ocr.env on CT 215")
    return values[URL_KEY], values[TOKEN_KEY]


def run(args: argparse.Namespace, client: OcrClient, out: TextIO, err: TextIO) -> int:
    if args.command == "status":
        _dump(client.status(), out)
        return EXIT_OK
    wait = {"wait": not args.no_wait, "timeout_s": args.timeout}
    if args.command == "read":
        answer = client.read(Source.of(args.source), mode=args.mode, pages=args.pages, **wait)
    elif args.command == "extract":
        answer = client.extract(Source.of(args.source), instruction=_text_arg(args.instruction),
                                schema=_schema(args.schema), context=args.context, pages=args.pages, **wait)
    else:
        answer = client.job(args.job_id, **wait)
    return _show(answer, out, err, as_json=args.json)


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")     # Czech text on a Windows console
    args = parser().parse_args(argv)
    try:
        url, token = settings(os.environ)
        with connect(url, token) as http:
            client = OcrClient(http, on_progress=_progress_printer(sys.stderr),
                               on_outdated=lambda message: print(f"fabric-ocr: warning: {message}", file=sys.stderr))
            return run(args, client, sys.stdout, sys.stderr)
    except OcrApiError as exc:
        print(f"fabric-ocr: {exc}", file=sys.stderr)
        return EXIT_ERROR


def _show(answer: dict[str, Any], out: TextIO, err: TextIO, *, as_json: bool) -> int:
    if answer.get("state") == "running":                  # --no-wait and not finished yet
        print(answer["job_id"], file=out)
        print(f"still working{_progress(answer)} - later: fabric-ocr job {answer['job_id']}", file=err)
        return EXIT_OK
    if as_json:
        _dump(answer, out)
    elif "data" in answer:
        _dump(answer["data"], out)
    else:
        out.write(str(answer.get("markdown", "")).rstrip("\n") + "\n")
    quality = str(answer.get("quality", FULL_QUALITY))
    print(f"route {answer.get('route')}, quality {quality}, pages {answer.get('pages')}, "
          f"{answer.get('duration_s')} s", file=err)
    for warning in answer.get("warnings") or []:
        print(f"warning: {warning}", file=err)
    return EXIT_OK if quality == FULL_QUALITY else EXIT_LOW_QUALITY


def _progress_printer(err: TextIO) -> Any:
    last = [""]

    def show(answer: dict[str, Any]) -> None:
        line = f"working{_progress(answer)} (job {answer.get('job_id')})"
        if line != last[0]:
            print(line, file=err, flush=True)
            last[0] = line
    return show


def _progress(answer: dict[str, Any]) -> str:
    return f", {answer['progress']}" if answer.get("progress") else ""


def _text_arg(value: str) -> str:
    if value.startswith("@"):
        return _read_file(Path(value[1:])).strip()
    return value


def _schema(path: Path) -> dict[str, Any]:
    try:
        schema = json.loads(_read_file(path))
    except json.JSONDecodeError as exc:
        raise OcrApiError(0, f"{path}: not valid JSON ({exc})") from exc
    if not isinstance(schema, dict):
        raise OcrApiError(0, f"{path}: a JSON Schema must be an object")
    return schema


def _read_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError as exc:
        raise OcrApiError(0, f"cannot read {path}: {exc.strerror}") from exc


def _env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        key, sep, value = line.strip().partition("=")
        if sep and not key.startswith("#"):
            values[key.strip()] = value.strip().strip("\"'")
    return values


def _dump(value: Any, out: TextIO) -> None:
    json.dump(value, out, ensure_ascii=False, indent=2)
    out.write("\n")


if __name__ == "__main__":
    sys.exit(main())
