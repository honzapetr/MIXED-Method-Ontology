"""The OCR service's REST API (fabric/services/mcp-hub/ocr/README.md): send a file, wait for the job, collect the text.

`200` = finished, `202` = still working (`job_id`, `Retry-After`) - the client then asks `GET /v1/jobs/<id>` until
the job ends. A long text comes in parts (`next_offset`); the client joins them, so callers get the whole result.
"""

import base64
import itertools
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from fabric_ocr import __version__

DEFAULT_POLL_S = 15.0           # when the service sends no Retry-After
DEFAULT_TIMEOUT_S = 3600.0      # Extract of a hard page took 16 min; the service keeps a job for an hour
REQUEST_TIMEOUT_S = 120.0       # one HTTP call: the service itself answers within its wait_s (at most 90 s)
TEXT_FIELDS = ("markdown", "text")   # read answers `markdown`, extract `text`
MIN_CLIENT_HEADER = "X-Fabric-Min-Client"   # the oldest client the service still works with (navrh-klienti-a-balicky.md §4)


class OcrApiError(Exception):
    """The service refused or the job failed; `status` is the HTTP status (0 = no answer)."""

    def __init__(self, status: int, detail: str) -> None:
        super().__init__(f"{status}: {detail}" if status else detail)
        self.status = status
        self.detail = detail


@dataclass(frozen=True)
class Source:
    """What to read: a URL the service downloads itself (allowed hosts only), or the bytes of a local file."""

    url: str = ""
    data: bytes = b""
    name: str = ""

    @classmethod
    def of(cls, where: str) -> "Source":
        if where.startswith(("http://", "https://")):
            return cls(url=where, name=where)
        path = Path(where)
        if not path.is_file():
            raise OcrApiError(0, f"no such file: {where}")
        return cls(data=path.read_bytes(), name=path.name)

    def json_part(self) -> dict[str, str]:
        return {"url": self.url} if self.url else {"data_base64": base64.b64encode(self.data).decode("ascii")}


class OcrClient:
    """One OCR service; `http` carries the base URL and the app's token (see `connect`)."""

    def __init__(self, http: httpx.Client, *, sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic,
                 on_progress: Callable[[dict[str, Any]], None] | None = None,
                 on_outdated: Callable[[str], None] | None = None, client_version: str = __version__) -> None:
        self._http = http
        self._sleep = sleep
        self._clock = clock
        self._on_progress = on_progress
        self._on_outdated = on_outdated
        self._version = client_version
        self._outdated_told = False

    def read(self, source: Source, *, mode: str = "auto", pages: str = "", wait: bool = True,
             timeout_s: float = DEFAULT_TIMEOUT_S) -> dict[str, Any]:
        """Read: the file → Markdown. A local file goes as the request body, a URL as JSON."""
        options = {key: value for key, value in (("mode", mode), ("pages", pages)) if value}
        if source.url:
            response = self._send("POST", "/v1/read", json={**source.json_part(), **options})
        else:
            response = self._send("POST", "/v1/read", params=options, content=source.data,
                                  headers={"Content-Type": "application/octet-stream"})
        return self._finish(response, wait=wait, timeout_s=timeout_s)

    def extract(self, source: Source, *, instruction: str, schema: dict[str, Any], context: str = "", pages: str = "",
                wait: bool = True, timeout_s: float = DEFAULT_TIMEOUT_S) -> dict[str, Any]:
        """Extract: the file + instruction + JSON Schema → `data` valid against the schema (the main model reads it)."""
        body: dict[str, Any] = {**source.json_part(), "instruction": instruction, "schema": schema}
        if context:
            body["context"] = context
        if pages:
            body["pages"] = pages
        return self._finish(self._send("POST", "/v1/extract", json=body), wait=wait, timeout_s=timeout_s)

    def job(self, job_id: str, *, wait: bool = True, timeout_s: float = DEFAULT_TIMEOUT_S) -> dict[str, Any]:
        """A job started earlier (`--no-wait`): its state, or the whole result once it is done."""
        return self._finish(self._send("GET", f"/v1/jobs/{job_id}"), wait=wait, timeout_s=timeout_s)

    def status(self) -> dict[str, Any]:
        return _json(self._send("GET", "/v1/status"))

    def _finish(self, response: httpx.Response, *, wait: bool, timeout_s: float) -> dict[str, Any]:
        """Poll a running job until it ends (or `timeout_s`), then join a text sent in parts."""
        deadline = self._clock() + timeout_s
        answer = _json(response)
        while response.status_code == 202 and wait:
            if self._on_progress:
                self._on_progress(answer)
            pause = _retry_after(response)
            if self._clock() + pause > deadline:
                raise OcrApiError(0, f"job {answer.get('job_id')} still running after {timeout_s:.0f} s - "
                                     f"ask later: fabric-ocr job {answer.get('job_id')}")
            self._sleep(pause)
            response = self._send("GET", f"/v1/jobs/{answer['job_id']}")
            answer = _json(response)
        return self._rest_of_text(answer)

    def _rest_of_text(self, answer: dict[str, Any]) -> dict[str, Any]:
        field = next((f for f in TEXT_FIELDS if f in answer), None)
        if field is None or "next_offset" not in answer:
            return answer
        parts = [str(answer[field])]
        part = answer
        while "next_offset" in part:
            part = _json(self._send("GET", f"/v1/jobs/{answer['job_id']}", params={"offset": part["next_offset"]}))
            parts.append(str(part.get(field, "")))
        return {key: value for key, value in answer.items() if key != "next_offset"} | {field: "".join(parts)}

    def _send(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        try:
            response = self._http.request(method, path, **kwargs)
        except httpx.HTTPError as exc:
            raise OcrApiError(0, f"the OCR service did not answer: {exc}") from exc
        self._check_version(response)
        if response.status_code >= 400:
            raise OcrApiError(response.status_code, _detail(response))
        return response

    def _check_version(self, response: httpx.Response) -> None:
        """Tell once when the service says this client is older than it supports (it may still work, or not)."""
        minimum = response.headers.get(MIN_CLIENT_HEADER, "")
        if self._outdated_told or not self._on_outdated or not minimum or not is_older(self._version, minimum):
            return
        self._outdated_told = True
        self._on_outdated(f"this client {self._version} is older than the service supports ({minimum}) - "
                          "upgrade: uv tool upgrade fabric-ocr (or raise the version in your project)")


def connect(url: str, token: str, *, timeout_s: float = REQUEST_TIMEOUT_S) -> httpx.Client:
    return httpx.Client(base_url=url.rstrip("/"), timeout=timeout_s,
                        headers={"Authorization": f"Bearer {token}", "User-Agent": f"fabric-ocr/{__version__}"})


def is_older(version: str, minimum: str) -> bool:
    """`0.1.0` < `0.2.0` by the numeric parts (X.Y.Z of our own releases; a suffix like `.dev1` is ignored)."""
    return _numbers(version) < _numbers(minimum)


def _numbers(version: str) -> tuple[int, ...]:
    parts = []
    for part in version.split(".")[:3]:
        digits = "".join(itertools.takewhile(str.isdigit, part))
        parts.append(int(digits or 0))
    return tuple(parts + [0] * (3 - len(parts)))


def _json(response: httpx.Response) -> dict[str, Any]:
    try:
        body = response.json()
    except ValueError as exc:
        raise OcrApiError(response.status_code, f"not JSON: {response.text[:200]}") from exc
    if not isinstance(body, dict):
        raise OcrApiError(response.status_code, "the answer is not a JSON object")
    return body


def _detail(response: httpx.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        return response.text[:500] or response.reason_phrase
    return str(body.get("detail") or body) if isinstance(body, dict) else str(body)


def _retry_after(response: httpx.Response) -> float:
    try:
        return max(1.0, float(response.headers.get("Retry-After", DEFAULT_POLL_S)))
    except ValueError:
        return DEFAULT_POLL_S
